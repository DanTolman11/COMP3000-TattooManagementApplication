package bookings

type Booking struct{
	Id int
	ClientName string
}
