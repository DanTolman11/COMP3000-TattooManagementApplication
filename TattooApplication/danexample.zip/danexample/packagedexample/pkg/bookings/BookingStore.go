package bookings

import "fmt"

type BookingStore struct{
	bookings []*Booking
}

func (bookingStore *BookingStore) SaveBooking(booking *Booking) error {
	if !ValidateBooking(booking){
		return fmt.Errorf("Invalid booking")
	}
	bookingStore.bookings = append(bookingStore.bookings, booking)
	return nil
}

func (bookingStore *BookingStore) GetBookingById(id int) (*Booking, error) {
	if id >= len(bookingStore.bookings){
		return nil, fmt.Errorf("No booking for ID")
	}
	return bookingStore.bookings[id], nil
}